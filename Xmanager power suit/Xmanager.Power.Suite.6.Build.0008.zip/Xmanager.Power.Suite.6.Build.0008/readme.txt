During install use key:
180807-116568-999990
Run program and close, open keygen and click "Fix Host + Register".